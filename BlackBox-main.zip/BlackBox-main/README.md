# BlackBox
Hardware für Labor Informatik und Produktentwicklung JB&amp;MS
Eine Black Box bestehend aus einem µController und einem Sensor (US) soll ein Abstand gemessen werden und über eine USB Schnittstelle (UART) an einem Rechner übergeben.
Die Daten werden mit c++ in Windows und Linux Systemen gelesen werden.
Aktualisierung der Daten: 1 sek.
