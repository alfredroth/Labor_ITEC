#include <iostream>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <cstring>

int main() {
    const char* portname = "/dev/ttyUSB0"; // Passe den Port bei Bedarf an

    // Öffne den seriellen Port
    int serial_port = open(portname, O_RDONLY | O_NOCTTY);
    if (serial_port < 0) {
        std::cerr << "Fehler beim Öffnen des Ports " << portname << ": " << strerror(errno) << std::endl;
        return 1;
    }

    // Konfiguriere die serielle Schnittstelle
    termios tty;
    memset(&tty, 0, sizeof tty);
    if (tcgetattr(serial_port, &tty) != 0) {
        std::cerr << "Fehler beim Lesen der Einstellungen: " << strerror(errno) << std::endl;
        close(serial_port);
        return 1;
    }

    // Setze Baudrate
    cfsetispeed(&tty, B115200); // Eingangsbaudrate
    cfsetospeed(&tty, B115200); // Ausgangsbaudrate

    // 8N1-Modus (8 Datenbits, keine Parität, 1 Stopbit)
    tty.c_cflag &= ~PARENB;  // keine Parität
    tty.c_cflag &= ~CSTOPB;  // 1 Stopbit
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;      // 8 Datenbits
    tty.c_cflag &= ~CRTSCTS; // kein Hardware-Flow-Control
    tty.c_cflag |= CREAD | CLOCAL;

    tty.c_lflag &= ~ICANON; // Nicht-kanonisch (raw mode)
    tty.c_lflag &= ~ECHO;   // Kein Echo
    tty.c_lflag &= ~ECHOE;
    tty.c_lflag &= ~ISIG;
    tty.c_iflag &= ~(IXON | IXOFF | IXANY); // Kein Software-Flow-Control
    tty.c_iflag &= ~(ICRNL | INLCR);
    tty.c_oflag &= ~OPOST;

    tty.c_cc[VMIN]  = 1; // mind. 1 Zeichen lesen
    tty.c_cc[VTIME] = 1; // Timeout (0.1 Sekunden)

    if (tcsetattr(serial_port, TCSANOW, &tty) != 0) {
        std::cerr << "Fehler beim Setzen der Einstellungen: " << strerror(errno) << std::endl;
        close(serial_port);
        return 1;
    }

    // Lese Daten vom Port
    char buffer[256];
    while (true) {
        int n = read(serial_port, buffer, sizeof(buffer) - 1);
        if (n > 0) {
            buffer[n] = '\0';
            std::cout << "Empfangen: " << buffer << std::endl;
        }
    }

    close(serial_port);
    return 0;
}
