// 22072025
// c++ Program um auf einem Jetson Nano über die USB Schnittstelle von einem µController zu lesen
// usb: USB0 Baud; Rate  115200
// µController ESP32
// c++ Program mit chat GPT erstellt / Baudrate in Zeile 29&30 von B9600 auf 115200 geändert - AR
// fuer Dauerlaauf in Zeile 54&65 "while" eingefügt - AR
// mit "cat /dev/ttyUSB0" kan der Port Testweise gelesen werden.

#include <iostream>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <cstring>

int main() {
    const char* port = "/dev/ttyUSB0";  // Port Nr.
    int serial_port = open(port, O_RDWR);

    if (serial_port < 0) {
        std::cerr << "Fehler beim Öffnen von " << port << ": " << strerror(errno) << std::endl;
        return 1;
    }

    // Konfiguration der seriellen Schnittstelle
    termios tty;
    if (tcgetattr(serial_port, &tty) != 0) {
        std::cerr << "Fehler beim Abrufen der Einstellungen: " << strerror(errno) << std::endl;
        close(serial_port);
        return 1;
    }

    cfsetispeed(&tty, 115200); // Baudrate für Eingabe
    cfsetospeed(&tty, 115200); // Baudrate für Ausgabe

    tty.c_cflag &= ~PARENB; // Keine Parität
    tty.c_cflag &= ~CSTOPB; // Ein Stoppbit
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;     // 8 Datenbits
    tty.c_cflag &= ~CRTSCTS;// Keine Hardware-Flusskontrolle
    tty.c_cflag |= CREAD | CLOCAL; // Einschalten der Lese- & lokalen Steuerung

    tty.c_lflag &= ~ICANON; // Kein Canonical-Modus
    tty.c_lflag &= ~ECHO;   // Kein Echo
    tty.c_lflag &= ~ECHOE;
    tty.c_lflag &= ~ISIG;
    tty.c_iflag &= ~(IXON | IXOFF | IXANY); // Keine Software-Flusskontrolle
    tty.c_iflag &= ~(ICRNL | INLCR);        // Kein Umwandeln von CR/LF
    tty.c_oflag &= ~OPOST; // Kein Post-Processing der Ausgabe

    tty.c_cc[VTIME] = 10;    // Timeout in 1/10 Sekunden (hier: 1 Sekunde)
    tty.c_cc[VMIN] = 10;      // Minimale Anzahl an Zeichen (Minimum 3 AR)

    tcsetattr(serial_port, TCSANOW, &tty);

    // Lesen
    while (true) {
    char buffer[256];
    memset(&buffer, '\0', sizeof(buffer));

    int num_bytes = read(serial_port, &buffer, sizeof(buffer));

    if (num_bytes < 0) {
        std::cerr << "Lesefehler: " << strerror(errno) << std::endl;
    } else {
        std::cout << "Gelesen2: " << buffer << std::endl;
    }
    }

    close(serial_port);
    return 0;
}

