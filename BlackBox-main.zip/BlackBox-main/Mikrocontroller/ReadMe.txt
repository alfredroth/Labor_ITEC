HW: ESP32 helltec V3
SW: Micropython - Thonny
