# Wird einmal beim hochfahren ausgeführt
import machine
#from machine import ssd1306
from lib.ssd1306 import SSD1306_I2C
from machine import Pin, SoftI2C
import random

i2c = SoftI2C(scl=Pin(18), sda=Pin(17)) # I2C Bus für Display
reset=Pin(21, Pin.OUT,value=1) # Reset Pin für display muss 1->0->1 
reset.value(0)
reset.value(1)

display = SSD1306_I2C(128,64,i2c)
# 
display.fill(0)
display.text ("Micro Controller ",00,0) #Text in Zeile 1
display.text ("ESP32-V3 ",30,20) #Text in Zeile 2
display.text ("A Roth",30,45) #Text in Zeile 3
display.show()

for n in range (0,120):
    display.text (".",n,55) #Text in Zeile 3
    display.show()
    
display.fill(0)    
for n in range (0,50):
    x=random.randrange(1,100)
    y=random.randrange(1,50)
    display.text ("°",x,y) #Text in Zeile 3
    display.show()

# for n in range (0,120):
#     display.text ("*",n,n) #Text in Zeile 3
#     display.show()
    
    
