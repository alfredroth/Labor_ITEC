// cp++ Programmzum auslesen eines USP Port's 22072025AR
#include <windows.h>
#include <iostream>
#include <stdlib.h>

int main() {
    HANDLE hSerial;
    LPCSTR portName = "\\\\.\\COM4"; // Ersetze COM3 durch deinen Port (z. B. COM1, COM4)

    hSerial = CreateFile(portName,
        GENERIC_READ,
        0,
        NULL,
        OPEN_EXISTING,
        0,
        NULL);

    if (hSerial == INVALID_HANDLE_VALUE) {
        std::cerr << "Fehler beim Öffnen des COM-Ports!" << std::endl;
        return 1;
    }

    // Konfiguration des Ports
    DCB dcbSerialParams = { 0 };
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);

    if (!GetCommState(hSerial, &dcbSerialParams)) {
        std::cerr << "Fehler beim Abrufen der aktuellen Schnittstellenparameter!" << std::endl;
        CloseHandle(hSerial);
        return 1;
    }

    dcbSerialParams.BaudRate = CBR_115200;
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity = NOPARITY;

    if (!SetCommState(hSerial, &dcbSerialParams)) {
        std::cerr << "Fehler beim Setzen der Schnittstellenparameter!" << std::endl;
        CloseHandle(hSerial);
        return 1;
    }

    // Timeout-Einstellungen
    COMMTIMEOUTS timeouts = { 0 };
    timeouts.ReadIntervalTimeout = 50;
    timeouts.ReadTotalTimeoutConstant = 50;
    timeouts.ReadTotalTimeoutMultiplier = 10;

    SetCommTimeouts(hSerial, &timeouts);

    // Daten lesen
    char szBuff[256] = { 0 };
    DWORD dwBytesRead = 0;

    while (true) {
        if (ReadFile(hSerial, szBuff, sizeof(szBuff) - 1, &dwBytesRead, NULL)) {
            if (dwBytesRead > 0) {
                szBuff[dwBytesRead] = '\0'; // Null-Terminierung
                system("cls"); 
                std::cout << "Abstand: \n" << szBuff << std::endl;// Ausgabe vom eingelesenenm Wert
            }
        }
        else {
            std::cerr << "Fehler beim Lesen!" << std::endl;
            break;
        }
        Sleep(100); // kleine Pause
    }

    CloseHandle(hSerial);
    return 0;
}
